setTimeout(() => {
    window.location.reload(true);
}, 2500);