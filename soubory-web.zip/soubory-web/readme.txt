Doporučuji si do <head></head> přidat link na script.js, nebudeš muset dávat refresh stránky. Můžeš si v tom skriptu změnit čas refresh stránky. Pokud budeš ten skript používat a nebude vadit funkčnosti stránky, nech ho tam ale nastav ho na 10s.

skript přidáš pomocí:

<script defer src="./script.js"></script>

btw musí ten javascript soubor být ve stejné složce jako index.html
klidně ten skript dej na všechny html stránky